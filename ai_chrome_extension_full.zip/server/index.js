// Minimal Express server with Stripe + Supabase stubs
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const Stripe = require('stripe');
const { createClient } = require('@supabase/supabase-js');
const fetch = require('node-fetch');
const app = express();
app.use(cors());
app.use(bodyParser.json());
const PORT = process.env.PORT || 3000;
const STRIPE_SECRET = process.env.STRIPE_SECRET || 'sk_test_xxx';
const STRIPE_PRICE_PREMIUM = process.env.STRIPE_PRICE_PREMIUM || 'price_xxx';
const stripe = Stripe(STRIPE_SECRET);
const SUPABASE_URL = process.env.SUPABASE_URL || 'https://your-supabase-url';
const SUPABASE_KEY = process.env.SUPABASE_KEY || 'supabase_key';
const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);
app.post('/api/summarize', async (req, res) => {
  const { text, mode } = req.body || {};
  if (!text) return res.status(400).json({ error: 'no text' });
  const start = Date.now();
  try {
    const summary = text.slice(0, 400) + (text.length>400 ? '\n\n[truncated summary — implement real model call]' : '');
    const latency_ms = Date.now() - start;
    supabase.from('events').insert([{ name:'summarize', latency_ms, success: true, properties: { mode } }]).catch(()=>{});
    return res.json({ summary, latency_ms });
  } catch (err) {
    console.error(err);
    supabase.from('events').insert([{ name:'summarize', success:false }]).catch(()=>{});
    return res.status(500).json({ error: 'internal' });
  }
});
app.post('/api/create-checkout-session', async (req, res) => {
  try {
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      mode: 'subscription',
      line_items: [{ price: STRIPE_PRICE_PREMIUM, quantity: 1 }],
      success_url: 'https://example.com/success?session_id={CHECKOUT_SESSION_ID}',
      cancel_url: 'https://example.com/cancel'
    });
    res.json({ url: session.url });
  } catch (err) {
    console.error(err); res.status(500).json({error: err.message});
  }
});
app.post('/webhook', bodyParser.raw({type:'application/json'}), (req, res) => {
  console.log('Webhook received'); res.status(200).send('ok');
});
app.post('/api/analytics/event', async (req, res) => {
  const ev = req.body || {};
  try {
    await supabase.from('events').insert([{ name: ev.name||'unknown', latency_ms: ev.latency_ms||null, success: ev.success===false?false:true, properties: ev.properties||null }]);
  } catch (e) { console.error('supabase log error', e); }
  res.json({ ok: true });
});
app.get('/', (req, res) => res.send('WebSummarize server up. Configure env vars to enable Stripe & Supabase.'));
app.listen(PORT, ()=> console.log('Server listening on', PORT));
