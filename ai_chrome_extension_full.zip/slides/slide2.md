# Slide 2 — Solution
WebSummarize: highlight → click → instant summary. Free tier + Premium subscription.