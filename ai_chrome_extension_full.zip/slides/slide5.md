# Slide 5 — Next steps
Offline model, smarter chunking, export integrations.