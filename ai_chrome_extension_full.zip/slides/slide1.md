# Slide 1 — Problem
People waste time reading long articles; need quick, reliable summaries.