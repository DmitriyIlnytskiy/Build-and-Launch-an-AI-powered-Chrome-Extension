# Slide 3 — Demo
Highlight text, click Summarize, copy/export, view analytics.